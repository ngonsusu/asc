# tests/test_downloader.py

import unittest
from core.downloader import Downloader
from unittest.mock import patch, MagicMock

class TestDownloader(unittest.TestCase):
    
    @patch('core.downloader.requests.get')
    def test_download_tool(self, mock_get):
        # Arrange
        downloader = Downloader("/path/to/save")
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.iter_content.return_value = [b"test"]
        mock_get.return_value = mock_response

        # Act
        downloader.download_tool("https://example.com", "/path/to/save/test.zip")
        
        # Assert
        mock_get.assert_called_once_with("https://example.com", timeout=60, stream=True)
        self.assertTrue(os.path.exists("/path/to/save/test.zip"))

if __name__ == '__main__':
    unittest.main()
