# main.py

import sys
from PyQt5.QtWidgets import QApplication
from gui.main_window import MainWindow
from core.config import Config  # Import Config class

if __name__ == "__main__":
    # Tạo đối tượng Config
    config = Config()
    
    # Truyền config vào MainWindow
    app = QApplication(sys.argv)
    window = MainWindow(config)  # Truyền config vào constructor
    window.show()
    sys.exit(app.exec_())
