# plugins/base_plugin.py

class BasePlugin:
    def __init__(self, config):
        self.config = config

    def run(self):
        raise NotImplementedError("Plugin should implement the 'run' method.")

# plugins/plugin_example.py

from .base_plugin import BasePlugin

class PluginExample(BasePlugin):
    def run(self):
        print("Running Plugin Example with config:", self.config)
