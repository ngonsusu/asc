# gui/main_window.py

from PyQt5.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QTabWidget
from gui.scan_tab import ScanTab  # Dùng import tuyệt đối
from gui.brute_tab import BruteTab

class MainWindow(QMainWindow):
    def __init__(self, config):
        super().__init__()
        self.config = config  # Lưu đối tượng config vào trong đối tượng MainWindow
        self.setWindowTitle("Network Scanner - RDP Brute-Force Tool")
        self.setGeometry(100, 100, 1200, 900)
        self.init_ui()

    def init_ui(self):
        main_widget = QWidget()
        main_layout = QVBoxLayout()

        # Create tabs for scan and brute-force
        self.tabs = QTabWidget()
        scan_tab = ScanTab(self.config)  # Truyền config vào ScanTab
        brute_tab = BruteTab(self.config)  # Truyền config vào BruteTab
        self.tabs.addTab(scan_tab, "Quét dịch vụ")
        self.tabs.addTab(brute_tab, "Crack RDP")

        main_layout.addWidget(self.tabs)
        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

        # Apply theme
        self.apply_theme()

    def apply_theme(self):
        if self.config.get_theme() == "dark":
            self.setStyleSheet("QWidget {background-color: #2f2f2f; color: white;} QPushButton {background-color: #212121; color: white;}")
        else:
            self.setStyleSheet("QWidget {background-color: #f0f0f0; color: black;} QPushButton {background-color: #4CAF50; color: white;}")
