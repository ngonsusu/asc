# gui/brute_tab.py

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QGroupBox, QGridLayout, QComboBox, QPushButton, QLineEdit, QSpinBox, QLabel
from core.brute_force import BruteForce

class BruteTab(QWidget):
    def __init__(self, config):
        super().__init__()
        self.config = config  # Nhận config và lưu lại trong đối tượng
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        rdp_group = QGroupBox("Cài đặt crack RDP")
        rdp_layout = QGridLayout()

        rdp_layout.addWidget(QLabel("User list:"), 0, 0)
        self.user_file_input = QLineEdit()
        rdp_layout.addWidget(self.user_file_input, 0, 1)

        rdp_layout.addWidget(QLabel("Pass list:"), 1, 0)
        self.pass_file_input = QLineEdit()
        rdp_layout.addWidget(self.pass_file_input, 1, 1)

        rdp_layout.addWidget(QLabel("Công cụ:"), 2, 0)
        self.brute_tool_combo = QComboBox()
        self.brute_tool_combo.addItems(["Hydra", "Ncrack"])
        rdp_layout.addWidget(self.brute_tool_combo, 2, 1)

        rdp_layout.addWidget(QLabel("Số luồng brute-force:"), 3, 0)
        self.brute_thread_count = QSpinBox()
        rdp_layout.addWidget(self.brute_thread_count, 3, 1)

        btn_brute = QPushButton("Crack RDP")
        rdp_layout.addWidget(btn_brute, 4, 0, 1, 2)

        rdp_group.setLayout(rdp_layout)
        layout.addWidget(rdp_group)

        self.setLayout(layout)

    def start_brute_force(self):
        tool_path = "path_to_tool"
        targets = [("192.168.1.100", "3389", "RDP")]
        user_file = self.user_file_input.text()
        pass_file = self.pass_file_input.text()

        brute_force = BruteForce(tool_path, targets, user_file, pass_file)
        results = brute_force.attack_target("192.168.1.100", "3389", "RDP")
        self.update_results(results)

    def update_results(self, results):
        for credential in results:
            print(f"Found credentials: {credential}")
