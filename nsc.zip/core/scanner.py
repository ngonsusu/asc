import subprocess
import re
from .utilities import log_to_file

class Scanner:
    def __init__(self, nmap_path):
        self.nmap_path = nmap_path

    def scan_target(self, target, port, service):
        """Quét dịch vụ bằng Nmap."""
        cmd = [
            self.nmap_path,
            "-n",
            "-p", port,
            "--open",
            target,
            "--script", f"{service.lower()}-enum-algos" if service != "RDP" else "rdp-enum-encryption"
        ]
        log_to_file(f"Running Nmap command: {' '.join(cmd)}")
        
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
        stdout, stderr = proc.communicate()
        
        if stderr:
            log_to_file(f"Error in Nmap scan: {stderr}")
            return []
        
        return self.parse_output(stdout)

    def parse_output(self, output):
        """Phân tích kết quả từ Nmap."""
        blocks = re.split(r"Nmap scan report for ", output)
        results = []
        for block in blocks[1:]:
            lines = block.splitlines()
            if not lines:
                continue
            ip_line = lines[0].strip()
            ip_match = re.search(r"(\d+\.\d+\.\d+\.\d+)", ip_line)
            if ip_match:
                ip = ip_match.group(1)
                for line in lines:
                    port_match = re.search(r"(\d+)/tcp\s+open", line)
                    if port_match:
                        port = port_match.group(1)
                        results.append((ip, port))
        return results
