# core/config.py

class Config:
    def __init__(self):
        self.nmap_path = "path_to_nmap"
        self.hydra_path = "path_to_hydra"
        self.ncrack_path = "path_to_ncrack"
        self.scan_threads = 20
        self.brute_threads = 5
        self.theme = "light"  # Default theme

    def get_nmap_path(self):
        return self.nmap_path

    def get_hydra_path(self):
        return self.hydra_path

    def get_ncrack_path(self):
        return self.ncrack_path

    def get_scan_threads(self):
        return self.scan_threads

    def get_brute_threads(self):
        return self.brute_threads

    def get_theme(self):
        return self.theme

    def set_theme(self, theme):
        self.theme = theme
