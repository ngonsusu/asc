# core/command_builder.py

class CommandBuilder:
    def __init__(self, tool_path):
        self.tool_path = tool_path
        self.command = [self.tool_path]

    def add_option(self, option, value):
        self.command.append(option)
        self.command.append(value)
        return self

    def build(self):
        return self.command
