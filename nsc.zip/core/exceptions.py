# core/exceptions.py

class NetworkScannerException(Exception):
    """Base exception class for the Network Scanner application"""
    pass

class DownloadException(NetworkScannerException):
    """Exception raised for download related errors"""
    pass

class ScanException(NetworkScannerException):
    """Exception raised for scanning related errors"""
    pass

class BruteForceException(NetworkScannerException):
    """Exception raised for brute force related errors"""
    pass
