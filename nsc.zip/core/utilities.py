import os
from datetime import datetime

def log_to_file(message):
    """Ghi log vào file."""
    log_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scanner.log')
    with open(log_file_path, 'a', encoding='utf-8') as log_file:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_file.write(f"[{timestamp}] {message}\n")

def find_exe_in_dir(directory, name=""):
    """Tìm file .exe trong thư mục."""
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(".exe") and (not name or name in file.lower()):
                return os.path.join(root, file)
    return ""
