import os
import requests
import zipfile
import shutil
from .utilities import log_to_file

class Downloader:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.hydra_url = "https://github.com/maaaaz/thc-hydra-windows/releases/download/v9.1/thc-hydra-windows-v9.1.zip"
        self.nmap_url = "https://nmap.org/dist/nmap-7.97-setup.exe"
        self.ncrack_url = "https://nmap.org/ncrack/dist/ncrack-0.7-setup.exe"

    def download_tool(self, url, file_path):
        """Tải một công cụ từ URL."""
        r = requests.get(url, timeout=60, stream=True)
        if r.status_code != 200:
            raise Exception(f"Error downloading {url}: HTTP {r.status_code}")
        with open(file_path, "wb") as f:
            for chunk in r.iter_content(1024 * 128):
                f.write(chunk)
        log_to_file(f"Downloaded {url} to {file_path}")

    def extract_hydra(self, zip_path, extract_to):
        """Giải nén file Hydra."""
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_to)
        os.remove(zip_path)
        log_to_file(f"Extracted Hydra to {extract_to}")

    def install_tools(self):
        """Cài đặt các công cụ cần thiết (Hydra, Nmap, Ncrack)."""
        hydra_zip = os.path.join(self.base_dir, "hydra.zip")
        nmap_installer = os.path.join(self.base_dir, "nmap-7.97-setup.exe")
        ncrack_installer = os.path.join(self.base_dir, "ncrack-0.7-setup.exe")

        # Download Hydra, Nmap, Ncrack
        self.download_tool(self.hydra_url, hydra_zip)
        self.download_tool(self.nmap_url, nmap_installer)
        self.download_tool(self.ncrack_url, ncrack_installer)

        # Extract Hydra
        hydra_dir = os.path.join(self.base_dir, "hydra")
        self.extract_hydra(hydra_zip, hydra_dir)

        return hydra_dir, nmap_installer, ncrack_installer
