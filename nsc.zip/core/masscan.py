# core/masscan.py

import subprocess
import re
from .utilities import log_to_file

class MasscanScanner:
    def __init__(self, masscan_path):
        self.masscan_path = masscan_path

    def scan_target(self, target, port_range):
        """Quét cổng sử dụng Masscan"""
        cmd = [
            self.masscan_path,
            target,
            "-p", port_range,
            "--rate", "1000"  # Tốc độ quét (bạn có thể điều chỉnh tốc độ này)
        ]
        log_to_file(f"Running Masscan command: {' '.join(cmd)}")
        
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
        stdout, stderr = proc.communicate()
        
        if stderr:
            log_to_file(f"Error in Masscan scan: {stderr}")
            return []
        
        return self.parse_output(stdout)

    def parse_output(self, output):
        """Phân tích kết quả từ Masscan"""
        results = []
        lines = output.splitlines()
        for line in lines:
            match = re.match(r"(\d+\.\d+\.\d+\.\d+)\s+(\d+)", line)
            if match:
                ip = match.group(1)
                port = match.group(2)
                results.append((ip, port))
        return results
