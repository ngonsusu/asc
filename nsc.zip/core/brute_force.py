import subprocess
from .utilities import log_to_file

class BruteForce:
    def __init__(self, tool_path, targets, user_file, pass_file):
        self.tool_path = tool_path
        self.targets = targets
        self.user_file = user_file
        self.pass_file = pass_file

    def attack_target(self, ip, port, service):
        """Thực hiện brute-force với Hydra hoặc Ncrack."""
        cmd = [
            self.tool_path,
            "-I", "-v", "-V",
            "-L", self.user_file,
            "-P", self.pass_file,
            "-s", port,
            ip,
            service.lower()
        ]
        log_to_file(f"Running brute-force command: {' '.join(cmd)}")
        
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding="utf-8")
        stdout, stderr = proc.communicate()
        
        if stderr:
            log_to_file(f"Error in brute-force: {stderr}")
            return []

        return self.parse_output(stdout)

    def parse_output(self, output):
        """Phân tích kết quả từ brute-force."""
        credentials = []
        for line in output.splitlines():
            if "login:" in line and "password:" in line:
                parts = line.split()
                try:
                    username = parts[parts.index("login:") + 1]
                    password = parts[parts.index("password:") + 1]
                    credentials.append(f"{username}:{password}")
                except IndexError:
                    continue
        return credentials
