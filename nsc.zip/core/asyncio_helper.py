# core/asyncio_helper.py

import asyncio
import requests

async def download_tool_async(url, file_path):
    r = await asyncio.to_thread(requests.get, url, timeout=60, stream=True)
    if r.status_code != 200:
        raise Exception(f"Error downloading {url}: HTTP {r.status_code}")
    with open(file_path, "wb") as f:
        for chunk in r.iter_content(1024 * 128):
            f.write(chunk)

async def run_downloader():
    url = "https://example.com/tool.zip"
    file_path = "/path/to/tool.zip"
    await download_tool_async(url, file_path)

# Run this with an event loop
asyncio.run(run_downloader())
